// This file contains initialization for the questions directory page
// Initialize an empty quizData for the directory page
var quizData = { questions: [] };
var totalQuestions = 0;

console.log("Quiz page initialized with empty quiz data for directory view"); 