// Quiz history management script
console.log("Quiz history script loaded");

let historyArray = []; // Global variable to store history data

document.addEventListener('DOMContentLoaded', function() {
    console.log("Initializing quiz history functionality");
    
    // Initialize direct history button
    const historyButton = document.getElementById('historyButton');
    if (historyButton) {
        historyButton.addEventListener('click', function(e) {
            e.preventDefault();
            // Load and show history modal with list view
            loadHistoryModal();
        });
        console.log("Direct history button initialized");
    } else {
        console.warn("Direct history button not found");
    }
    
    // Initialize modal close button
    const closeModal = document.getElementById('closeModal');
    const historyModal = document.getElementById('historyModal');
    
    if (closeModal && historyModal) {
        closeModal.addEventListener('click', function() {
            historyModal.style.display = 'none';
            // Reset to list view when closing modal
            showHistoryListView();
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === historyModal) {
                historyModal.style.display = 'none';
                // Reset to list view when closing modal
                showHistoryListView();
            }
        });
        console.log("History modal controls initialized");
    } else {
        console.warn("History modal elements not found");
    }
    
    // Initialize back button
    const backButton = document.getElementById('backToList');
    if (backButton) {
        backButton.addEventListener('click', function() {
            showHistoryListView();
        });
        console.log("Back button initialized");
    }
});

// Load history modal with list view
function loadHistoryModal() {
    console.log("Loading history modal");
    
    try {
        // Get history data
        const history = localStorage.getItem('quizHistory');
        historyArray = history ? JSON.parse(history) : [];
        
        // If no history records, show message
        if (historyArray.length === 0) {
            const historyRecords = document.getElementById('historyRecords');
            if (historyRecords) {
                historyRecords.innerHTML = '<div class="no-history-message">You have not completed any quizzes yet.</div>';
            }
            
            // Show modal with list view
            showHistoryListView();
            const historyModal = document.getElementById('historyModal');
            if (historyModal) historyModal.style.display = 'block';
            
            return;
        }
        
        // Sort by timestamp (newest first)
        historyArray.sort(function(a, b) {
            return b.timestamp - a.timestamp;
        });
        
        // Populate history records
        populateHistoryRecords(historyArray);
        
        // Show modal with list view
        showHistoryListView();
        const historyModal = document.getElementById('historyModal');
        if (historyModal) historyModal.style.display = 'block';
    } catch (error) {
        console.error("Error loading history modal:", error);
    }
}

// Show history list view and hide detail view
function showHistoryListView() {
    const listView = document.getElementById('historyListView');
    const detailView = document.getElementById('historyDetailView');
    
    if (listView) listView.style.display = 'block';
    if (detailView) detailView.style.display = 'none';
}

// Show history detail view and hide list view
function showHistoryDetailView() {
    const listView = document.getElementById('historyListView');
    const detailView = document.getElementById('historyDetailView');
    
    if (listView) listView.style.display = 'none';
    if (detailView) detailView.style.display = 'block';
}

// Populate history records list
function populateHistoryRecords(records) {
    const historyRecords = document.getElementById('historyRecords');
    if (!historyRecords) {
        console.error("History records container not found");
        return;
    }
    
    historyRecords.innerHTML = '';
    
    records.forEach(function(record, index) {
        const recordItem = document.createElement('div');
        recordItem.className = 'history-record-item';
        recordItem.addEventListener('click', function() {
            loadHistoryItem(record);
            showHistoryDetailView();
        });
        
        const recordTitle = document.createElement('div');
        recordTitle.className = 'history-record-title';
        recordTitle.textContent = record.title;
        
        const recordDate = document.createElement('div');
        recordDate.className = 'history-record-date';
        recordDate.textContent = 'Completed on: ' + record.date;
        
        recordItem.appendChild(recordTitle);
        recordItem.appendChild(recordDate);
        historyRecords.appendChild(recordItem);
    });
}

// Save quiz result to localStorage
function saveQuizResult(quizData, userScores, finalScores, maxScores, missedQuestions) {
    // Get current date
    const date = new Date();
    
    // Get quiz information
    const quizId = quizData.id || 'unknown';
    const quizTitle = quizData.title || 'Quiz Result';
    
    // Create result object
    const result = {
        id: quizId,
        title: quizTitle,
        date: date.toLocaleString(),
        timestamp: date.getTime(),
        rawScores: JSON.parse(JSON.stringify(userScores)), // Deep copy
        finalScores: JSON.parse(JSON.stringify(finalScores)), // Deep copy
        maxScores: JSON.parse(JSON.stringify(maxScores)), // Deep copy
        missedQuestions: missedQuestions // Add questions to review
    };
    
    // Get history from localStorage
    const history = localStorage.getItem('quizHistory');
    let historyArray = history ? JSON.parse(history) : [];
    
    // Add new result to history
    historyArray.push(result);
    
    // Limit history size (keep most recent 20)
    if (historyArray.length > 20) {
        historyArray = historyArray.slice(historyArray.length - 20);
    }
    
    // Save history to localStorage
    localStorage.setItem('quizHistory', JSON.stringify(historyArray));
    console.log("Quiz result saved to history:", result);
}

// Load history item and display in detail view
function loadHistoryItem(result) {
    console.log('Loading history item:', result);
    
    // Set modal title and date
    document.getElementById('historyModalTitle').textContent = result.title;
    document.getElementById('historyModalDate').textContent = 'Completed on: ' + result.date;
    
    // Generate radar chart
    createHistoryRadarChart(result.finalScores);
    
    // Fill score table
    const tableBody = document.getElementById('historyScoreTableBody');
    tableBody.innerHTML = '';
    
    const categories = {
        awareness: 'Awareness',
        confidence: 'Confidence',
        habits: 'Habits',
        support: 'Support',
        trust: 'Trust',
        preparedness: 'Preparedness'
    };
    
    for (const category in categories) {
        if (result.finalScores.hasOwnProperty(category)) {
            const row = document.createElement('tr');
            
            const categoryCell = document.createElement('td');
            categoryCell.className = 'score-category';
            categoryCell.textContent = categories[category];
            categoryCell.style.fontWeight = '600';
            categoryCell.style.color = '#212529';
            
            const rawScoreCell = document.createElement('td');
            rawScoreCell.textContent = result.rawScores[category];
            rawScoreCell.style.color = '#333';
            
            const maxScoreCell = document.createElement('td');
            maxScoreCell.textContent = result.maxScores[category];
            maxScoreCell.style.color = '#333';
            
            const finalScoreCell = document.createElement('td');
            finalScoreCell.textContent = result.finalScores[category].toFixed(1);
            
            // Set color based on score
            if (result.finalScores[category] >= 7) {
                finalScoreCell.style.color = '#28a745';
                finalScoreCell.style.fontWeight = 'bold';
            } else if (result.finalScores[category] >= 4) {
                finalScoreCell.style.color = '#414141';
                finalScoreCell.style.fontWeight = 'bold';
            } else {
                finalScoreCell.style.color = '#dc3545';
                finalScoreCell.style.fontWeight = 'bold';
            }
            
            row.appendChild(categoryCell);
            row.appendChild(rawScoreCell);
            row.appendChild(maxScoreCell);
            row.appendChild(finalScoreCell);
            
            tableBody.appendChild(row);
        }
    }
    
    // Show missed questions if available
    if (result.missedQuestions && result.missedQuestions.length > 0) {
        const missedQuestionsContainer = document.getElementById('historyMissedQuestionsList');
        missedQuestionsContainer.innerHTML = '';
        
        result.missedQuestions.forEach(function(missedQuestion) {
            const questionItem = document.createElement('div');
            questionItem.className = 'missed-question-item';
            questionItem.style.marginBottom = '20px';
            questionItem.style.padding = '15px';
            questionItem.style.backgroundColor = '#f8f9fa';
            questionItem.style.borderRadius = '5px';
            questionItem.style.border = '1px solid #ddd';
            
            const questionText = document.createElement('div');
            questionText.className = 'missed-question-text';
            questionText.textContent = missedQuestion.text;
            questionText.style.fontWeight = 'bold';
            questionText.style.marginBottom = '10px';
            questionText.style.color = '#212529'; // Dark text
            
            const userChoice = document.createElement('div');
            userChoice.style.color = '#212529 !important'; 
            userChoice.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
            userChoice.innerHTML = '<strong>Your choice:</strong> ' + missedQuestion.userChoice + 
                (missedQuestion.userChoiceScore ? ' (Total score: ' + missedQuestion.userChoiceScore + ')' : '');
            
            const betterChoice = document.createElement('div');
            betterChoice.className = 'correct-answer';
            betterChoice.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
            betterChoice.innerHTML = '<strong>Better choice:</strong> ' + missedQuestion.betterChoice + 
                (missedQuestion.betterChoiceScore ? ' (Total score: ' + missedQuestion.betterChoiceScore + ')' : '');
            
            const description = document.createElement('div');
            description.className = 'question-description';
            description.textContent = missedQuestion.description || 'No additional description';
            description.style.fontStyle = 'italic';
            description.style.marginTop = '10px';
            description.style.color = '#666';
            
            questionItem.appendChild(questionText);
            questionItem.appendChild(userChoice);
            questionItem.appendChild(betterChoice);
            questionItem.appendChild(description);
            
            missedQuestionsContainer.appendChild(questionItem);
        });
    } else {
        const emptyMissed = document.createElement('div');
        emptyMissed.textContent = 'Congratulations! You chose the highest scoring option in all questions.';
        emptyMissed.style.textAlign = 'center';
        emptyMissed.style.padding = '20px';
        emptyMissed.style.fontWeight = 'bold';
        emptyMissed.style.color = '#28a745';
        document.getElementById('historyMissedQuestionsList').innerHTML = '';
        document.getElementById('historyMissedQuestionsList').appendChild(emptyMissed);
    }
}

// Create history radar chart
function createHistoryRadarChart(finalScores) {
    createHistoryChart(finalScores, 'historyRadarChart', 'historyChart');
}

// Create chart for history view
function createHistoryChart(scores, chartId, chartInstanceName) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    // Check if chart instance already exists, if so, destroy it
    if (window[chartInstanceName]) {
        window[chartInstanceName].destroy();
    }
    
    window[chartInstanceName] = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Awareness', 'Confidence', 'Habits', 'Support', 'Trust', 'Preparedness'],
            datasets: [
                {
                    label: 'Scores',
                    data: [
                        scores.awareness,
                        scores.confidence, 
                        scores.habits,
                        scores.support,
                        scores.trust,
                        scores.preparedness
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(54, 162, 235, 1)',
                    fill: true
                }
            ]
        },
        options: {
            scales: {
                r: {
                    suggestedMin: 0,
                    suggestedMax: 10
                }
            }
        }
    });
} 