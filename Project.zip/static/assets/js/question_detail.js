// Menu dropdown control
document.addEventListener('DOMContentLoaded', function() {
    const menuButton = document.getElementById('menuButton');
    const historyDropdown = document.getElementById('historyDropdown');
    const historyModal = document.getElementById('historyModal');

    // Toggle dropdown menu when clicking the menu button
    menuButton.addEventListener('click', function() {
        if (historyDropdown.style.display === 'block') {
            historyDropdown.style.display = 'none';
        } else {
            historyDropdown.style.display = 'block';
            // Load history data when opening the dropdown
            loadHistoryData();
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (!menuButton.contains(event.target) && !historyDropdown.contains(event.target)) {
            historyDropdown.style.display = 'none';
        }
    });
    
    // Close modal when clicking the close button or outside the modal content
    document.addEventListener('click', function(event) {
        if (event.target === historyModal) {
            historyModal.style.display = 'none';
        }
    });
});

// Load quiz history data from the server
function loadHistoryData() {
    const historyDropdown = document.getElementById('historyDropdown');
    
    // Clear previous content
    historyDropdown.innerHTML = '';
    
    // Fetch history data from local storage
    const historyData = JSON.parse(localStorage.getItem('quizHistory')) || [];
    
    if (historyData.length === 0) {
        // Display message if no history found
        const emptyMessage = document.createElement('div');
        emptyMessage.className = 'empty-history';
        emptyMessage.textContent = 'No quiz history found.';
        historyDropdown.appendChild(emptyMessage);
        return;
    }
    
    // Create history items
    historyData.forEach(function(item, index) {
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';
        historyItem.textContent = `${item.quizTitle} - ${new Date(item.date).toLocaleDateString()}`;
        historyItem.addEventListener('click', function() {
            showHistoryDetails(item);
            historyDropdown.style.display = 'none';
        });
        historyDropdown.appendChild(historyItem);
    });
}

// Display detailed history for a specific quiz attempt
function showHistoryDetails(historyItem) {
    const historyModal = document.getElementById('historyModal');
    const historyTitle = document.getElementById('historyTitle');
    const historyDate = document.getElementById('historyDate');
    const scoreTable = document.getElementById('scoreTable');
    
    // Set title and date
    historyTitle.textContent = historyItem.quizTitle;
    historyDate.textContent = `Completed on: ${new Date(historyItem.date).toLocaleString()}`;
    
    // Clear previous scores
    scoreTable.innerHTML = '';
    
    // Add headers
    const headerRow = document.createElement('tr');
    const headers = ['Category', 'Description', 'Your Score'];
    headers.forEach(function(header) {
        const th = document.createElement('th');
        th.textContent = header;
        headerRow.appendChild(th);
    });
    scoreTable.appendChild(headerRow);
    
    // Add score data
    const categories = [
        'awareness', 'confidence', 'habits', 
        'support', 'trust', 'preparedness'
    ];
    
    const descriptions = {
        'awareness': 'Understanding of cybersecurity threats',
        'confidence': 'Belief in ability to handle security issues',
        'habits': 'Regular security practices and behavior',
        'support': 'Resources and help available for security',
        'trust': 'Confidence in digital systems and services',
        'preparedness': 'Readiness to respond to security incidents'
    };
    
    categories.forEach(function(category) {
        const row = document.createElement('tr');
        
        // Category name (capitalized)
        const categoryCell = document.createElement('td');
        categoryCell.className = 'score-category';
        categoryCell.textContent = category.charAt(0).toUpperCase() + category.slice(1);
        row.appendChild(categoryCell);
        
        // Description
        const descriptionCell = document.createElement('td');
        descriptionCell.className = 'score-description';
        descriptionCell.textContent = descriptions[category];
        row.appendChild(descriptionCell);
        
        // Score with color coding
        const scoreCell = document.createElement('td');
        scoreCell.className = 'user-score';
        const score = historyItem.scores[category] || 0;
        scoreCell.textContent = score;
        
        // Add color class based on score
        if (score > 0) {
            scoreCell.classList.add('positive-score');
        } else if (score < 0) {
            scoreCell.classList.add('negative-score');
        } else {
            scoreCell.classList.add('neutral-score');
        }
        
        row.appendChild(scoreCell);
        scoreTable.appendChild(row);
    });
    
    // Show the modal
    historyModal.style.display = 'block';
}

// Handle option selection for questions
document.addEventListener('DOMContentLoaded', function() {
    const optionsList = document.querySelector('.options-list');
    
    if (optionsList) {
        optionsList.addEventListener('click', function(event) {
            const optionItem = event.target.closest('.option-item');
            
            if (optionItem) {
                // Remove selected class from all options
                document.querySelectorAll('.option-item').forEach(function(item) {
                    item.classList.remove('selected');
                });
                
                // Add selected class to clicked option
                optionItem.classList.add('selected');
            }
        });
    }
    
    // Handle form submission
    const questionForm = document.getElementById('questionForm');
    if (questionForm) {
        questionForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const selectedOption = document.querySelector('.option-item.selected');
            if (!selectedOption) {
                alert('Please select an option before submitting.');
                return;
            }
            
            const optionId = selectedOption.getAttribute('data-option-id');
            document.getElementById('selectedOption').value = optionId;
            
            // Submit the form
            this.submit();
        });
    }
}); 