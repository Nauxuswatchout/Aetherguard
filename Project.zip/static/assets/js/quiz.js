// Initialize quiz data from window global variables
var quizData = window.quizData || {};
var totalQuestions = window.totalQuestions || 0;

// Quiz logic variables
var currentQuestion = 1;
var userScores = {
    awareness: 0,
    confidence: 0,
    habits: 0,
    support: 0,
    trust: 0,
    preparedness: 0
};
var userAnswers = [];

console.log("Quiz.js loaded - Ready to initialize");

// Main initialization function
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM fully loaded");
    console.log("Quiz data:", quizData);
    console.log("Total questions:", totalQuestions);
    
    try {
        // Check if we're on the quiz directory/listing page
        if (document.querySelector('.quiz-grid')) {
            console.log("On quiz directory page - no quiz data needed");
            return;
        }
        
        // Validate quiz data
        if (!quizData || !quizData.questions || !quizData.questions.length) {
            console.log("Quiz data not available or on a non-quiz page");
            return;
        }
        
        console.log("Valid quiz data found with " + quizData.questions.length + " questions");
        
        // Initialize start button
        initStartButton();
        
        // Initialize option selection
        initOptionSelection();
        
        // Initialize hint buttons
        initHintButtons();
        
        // Initialize restart button
        initRestartButton();
        
        // Initialize history functionality if needed
        if (document.getElementById('historyButton')) {
            initHistoryFunctionality();
        }
        
        console.log("Quiz initialization complete");
    } catch (error) {
        console.error("Error during quiz initialization:", error);
    }
});

// Initialize start button
function initStartButton() {
    var startButton = document.getElementById('startQuiz');
    if (!startButton) {
        console.error("Start button not found with ID 'startQuiz'");
        return;
    }
    
    console.log("Start button found, attaching event listener");
    
    startButton.addEventListener('click', function() {
        console.log("Start button clicked");
        
        // Get elements
        var quizHeader = document.querySelector('.quiz-header');
        var questionContainer = document.getElementById('questionContainer');
        
        // Hide quiz header
        if (quizHeader) {
            quizHeader.style.display = 'none';
            console.log("Quiz header hidden");
        } else {
            console.error("Quiz header element not found");
        }
        
        // Show question container
        if (questionContainer) {
            questionContainer.style.display = 'block';
            console.log("Question container shown");
        } else {
            console.error("Question container element not found");
        }
        
        // Show first question and update progress
        showQuestion(1);
        updateProgressBar();
        
        console.log("Quiz started successfully");
    });
}

// Initialize option selection
function initOptionSelection() {
    var optionItems = document.querySelectorAll('.option-item');
    console.log("Found " + optionItems.length + " option items");
    
    if (optionItems.length === 0) {
        console.error("No option items found with class 'option-item'");
        return;
    }
    
    for (var i = 0; i < optionItems.length; i++) {
        optionItems[i].addEventListener('click', handleOptionSelection);
    }
    
    console.log("Option selection initialized");
}

// Initialize hint buttons
function initHintButtons() {
    var hintButtons = document.querySelectorAll('.get-hint-button');
    console.log("Found " + hintButtons.length + " hint buttons");
    
    if (hintButtons.length === 0) {
        console.warn("No hint buttons found with class 'get-hint-button'");
        return;
    }
    
    for (var i = 0; i < hintButtons.length; i++) {
        hintButtons[i].addEventListener('click', function() {
            console.log("Hint button clicked for question " + this.getAttribute('data-question'));
            this.classList.toggle('flipped');
        });
    }
    
    console.log("Hint buttons initialized");
}

// Initialize restart button
function initRestartButton() {
    var restartButton = document.getElementById('restartQuiz');
    if (!restartButton) {
        console.warn("Restart button not found with ID 'restartQuiz'");
        return;
    }
    
    restartButton.addEventListener('click', restartQuiz);
    console.log("Restart button initialized");
}

// Initialize history functionality
function initHistoryFunctionality() {
    try {
        // Initialize history button
        var historyButton = document.getElementById('historyButton');
        if (historyButton) {
            historyButton.addEventListener('click', function(e) {
                e.preventDefault();
                var menuDropdown = document.querySelector('.menu-dropdown');
                if (menuDropdown) {
                    menuDropdown.classList.toggle('active');
                    updateHistoryDropdown();
                }
            });
        }
        
        // Initialize close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.menu-button') && !e.target.closest('.menu-dropdown')) {
                var menuDropdown = document.querySelector('.menu-dropdown');
                if (menuDropdown) {
                    menuDropdown.classList.remove('active');
                }
            }
        });
        
        // Initialize modal close button
        var closeModal = document.getElementById('closeModal');
        var historyModal = document.getElementById('historyModal');
        
        if (closeModal && historyModal) {
            closeModal.addEventListener('click', function() {
                historyModal.style.display = 'none';
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target === historyModal) {
                    historyModal.style.display = 'none';
                }
            });
        }
        
        console.log("History functionality initialized");
    } catch (error) {
        console.error("Error initializing history functionality:", error);
    }
}

// Show current question
function showQuestion(questionNumber) {
    console.log("Showing question:", questionNumber);
    
    try {
        // Validate question number
        if (questionNumber < 1 || questionNumber > totalQuestions) {
            console.error("Invalid question number:", questionNumber);
            return;
        }
        
        // Hide all questions
        var questionBoxes = document.querySelectorAll('.question-box');
        console.log("Found " + questionBoxes.length + " question boxes");
        
        if (questionBoxes.length === 0) {
            console.error("No question boxes found with class 'question-box'");
            return;
        }
        
        for (var i = 0; i < questionBoxes.length; i++) {
            questionBoxes[i].classList.remove('active');
        }
        
        // Show current question
        var currentQuestionBox = document.getElementById('question' + questionNumber);
        if (currentQuestionBox) {
            currentQuestionBox.classList.add('active');
            console.log("Question " + questionNumber + " displayed successfully");
        } else {
            console.error("Question box not found for question " + questionNumber);
        }
    } catch (error) {
        console.error("Error in showQuestion function:", error);
    }
}

// Update progress bar
function updateProgressBar() {
    try {
        var progressBar = document.getElementById('progressBar');
        if (!progressBar) {
            console.error("Progress bar element not found");
            return;
        }
        
        var progressPercentage = ((currentQuestion - 1) / totalQuestions) * 100;
        progressBar.style.width = progressPercentage + '%';
        
        // Update progress text
        var currentElement = document.getElementById('currentQuestionNumber');
        var percentageElement = document.getElementById('progressPercentage');
        
        if (currentElement) {
            currentElement.textContent = currentQuestion;
        }
        
        if (percentageElement) {
            percentageElement.textContent = Math.round(progressPercentage);
        }
        
        console.log("Progress updated: " + Math.round(progressPercentage) + "%");
    } catch (error) {
        console.error("Error in updateProgressBar function:", error);
    }
}

// Handle option selection
function handleOptionSelection() {
    try {
        var questionIndex = parseInt(this.getAttribute('data-question'));
        var optionIndex = parseInt(this.getAttribute('data-option')) - 1;
        
        console.log("Selected option:", questionIndex, optionIndex);
        
        // Remove selected class from all options for this question
        var questionOptions = document.querySelectorAll('.option-item[data-question="' + questionIndex + '"]');
        for (var j = 0; j < questionOptions.length; j++) {
            questionOptions[j].classList.remove('selected');
        }
        
        // Add selected class to clicked option
        this.classList.add('selected');
        
        // Update scores based on option selection
        if (quizData.questions && 
            quizData.questions[questionIndex] && 
            quizData.questions[questionIndex].options && 
            quizData.questions[questionIndex].options[optionIndex] &&
            quizData.questions[questionIndex].options[optionIndex].scores) {
            
            var optionScores = quizData.questions[questionIndex].options[optionIndex].scores;
            console.log("Option scores:", optionScores);
            
            // Update user scores
            for (var scoreType in optionScores) {
                if (optionScores.hasOwnProperty(scoreType)) {
                    userScores[scoreType] += optionScores[scoreType];
                }
            }
            
            // Store user's answer
            userAnswers[questionIndex] = optionIndex;
            
            // Move to next question after a delay
            setTimeout(function() {
                currentQuestion++;
                console.log("Moving to next question:", currentQuestion);
                
                if (currentQuestion <= totalQuestions) {
                    showQuestion(currentQuestion);
                    updateProgressBar();
                } else {
                    showResults();
                }
            }, 500);
        } else {
            console.error("Cannot find or access option scores. Quiz data may be corrupted.");
            console.log("Quiz data structure:", quizData);
        }
    } catch (error) {
        console.error("Error in handleOptionSelection function:", error);
    }
}

// Update history dropdown
function updateHistoryDropdown() {
    try {
        var historyList = document.getElementById('historyList');
        if (!historyList) {
            console.warn("History list element not found");
            return;
        }
        
        historyList.innerHTML = '';
        
        // Get history from localStorage
        var history = localStorage.getItem('quizHistory');
        var historyArray = history ? JSON.parse(history) : [];
        
        if (historyArray.length === 0) {
            historyList.innerHTML = '<div class="empty-history">No history records</div>';
            return;
        }
        
        // Sort history by timestamp (newest first)
        historyArray.sort(function(a, b) {
            return b.timestamp - a.timestamp;
        });
        
        // Add history items to dropdown
        historyArray.forEach(function(result) {
            var listItem = document.createElement('div');
            listItem.className = 'history-item';
            listItem.textContent = result.title + ' - ' + result.date;
            listItem.addEventListener('click', function() {
                loadHistoryItem(result);
            });
            historyList.appendChild(listItem);
        });
        
        console.log("History dropdown updated with " + historyArray.length + " items");
    } catch (error) {
        console.error("Error updating history dropdown:", error);
    }
}

// Show results
function showResults() {
    try {
        // Hide question container and show results
        var questionContainer = document.getElementById('questionContainer');
        var resultsContainer = document.getElementById('resultsContainer');
        
        if (questionContainer) {
            questionContainer.style.display = 'none';
        }
        
        if (resultsContainer) {
            resultsContainer.style.display = 'block';
        } else {
            console.error("Results container not found");
            return;
        }
        
        // Calculate maximum scores
        var categoryMaxScores = calculateCategoryMaxScores();
        
        // Calculate final normalized scores
        var finalScores = {
            awareness: calculateFinalScore(userScores.awareness, categoryMaxScores.awareness),
            confidence: calculateFinalScore(userScores.confidence, categoryMaxScores.confidence),
            habits: calculateFinalScore(userScores.habits, categoryMaxScores.habits),
            support: calculateFinalScore(userScores.support, categoryMaxScores.support),
            trust: calculateFinalScore(userScores.trust, categoryMaxScores.trust),
            preparedness: calculateFinalScore(userScores.preparedness, categoryMaxScores.preparedness)
        };
        
        // Update score displays
        updateScoreDisplay(finalScores);
        updateScoreExplanation(userScores, categoryMaxScores);
        updateDebugInfo(userScores, categoryMaxScores);
        
        // Create radar chart
        createRadarChart(finalScores, 'radarChart', 'mainChart');
        
        // Show questions to review
        showMissedQuestions();
        
        // Show improvement areas
        showImprovementAreas(finalScores);
        
        // Save result to history
        saveQuizResult(quizData, userScores, finalScores, categoryMaxScores);
        
        console.log("Results displayed successfully");
    } catch (error) {
        console.error("Error showing results:", error);
    }
}

// Calculate final score (normalized to 0-10 scale)
function calculateFinalScore(actualScore, maxPossibleScore) {
    // For negative scores, return 0
    if (actualScore < 0) {
        return 0;
    }
    
    // For zero maximum possible score, return 5 (middle value)
    if (maxPossibleScore === 0) {
        return 5;
    }
    
    // Calculate score ratio
    var scoreRatio = actualScore / maxPossibleScore;
    
    // For 0.5 ratio, return 5
    if (Math.abs(scoreRatio - 0.5) < 0.01) {
        return 5;
    }
    
    // Map ratio to 0-10 range, ensuring it doesn't exceed 10
    return Math.min(scoreRatio * 10, 10);
}

// Restart quiz
function restartQuiz() {
    try {
        // Reset scores
        for (var scoreType in userScores) {
            if (userScores.hasOwnProperty(scoreType)) {
                userScores[scoreType] = 0;
            }
        }
        
        // Reset answers
        userAnswers = [];
        
        // Reset question number
        currentQuestion = 1;
        
        // Remove selected class from all options
        var selectedOptions = document.querySelectorAll('.option-item.selected');
        for (var i = 0; i < selectedOptions.length; i++) {
            selectedOptions[i].classList.remove('selected');
        }
        
        // Hide results and show quiz header
        var resultsContainer = document.getElementById('resultsContainer');
        var quizHeader = document.querySelector('.quiz-header');
        var questionContainer = document.getElementById('questionContainer');
        
        if (resultsContainer) {
            resultsContainer.style.display = 'none';
        }
        
        if (quizHeader) {
            quizHeader.style.display = 'block';
        }
        
        if (questionContainer) {
            questionContainer.style.display = 'none';
        }
        
        // Reset progress bar
        updateProgressBar();
        
        console.log("Quiz restarted successfully");
    } catch (error) {
        console.error("Error restarting quiz:", error);
    }
}

// Calculate maximum possible score for each category
function calculateCategoryMaxScores() {
    var maxScores = {
        awareness: totalQuestions * 5,
        confidence: totalQuestions * 5,
        habits: totalQuestions * 5,
        support: totalQuestions * 5,
        trust: totalQuestions * 5,
        preparedness: totalQuestions * 5
    };
    
    return maxScores;
}

// Collect missed questions function
function collectMissedQuestions(quizData, userAnswers) {
    var missedQuestions = [];
    
    // Loop through all questions
    for (var i = 0; i < quizData.questions.length; i++) {
        var question = quizData.questions[i];
        var userAnswer = userAnswers[i];
        
        if (userAnswer !== undefined) {
            // Find the total score for user's option
            var userOptionTotalScore = 0;
            var userOption = question.options[userAnswer];
            for (var category in userOption.scores) {
                if (userOption.scores.hasOwnProperty(category)) {
                    userOptionTotalScore += userOption.scores[category];
                }
            }
            
            // Find the highest scoring option
            var maxTotalScore = -Infinity;
            var bestOptionIndex = -1;
            
            for (var j = 0; j < question.options.length; j++) {
                var option = question.options[j];
                var optionTotalScore = 0;
                
                for (var category in option.scores) {
                    if (option.scores.hasOwnProperty(category)) {
                        optionTotalScore += option.scores[category];
                    }
                }
                
                if (optionTotalScore > maxTotalScore) {
                    maxTotalScore = optionTotalScore;
                    bestOptionIndex = j;
                }
            }
            
            // If user didn't choose the highest scoring option, add to missed questions
            if (bestOptionIndex !== userAnswer) {
                missedQuestions.push({
                    text: question.text,
                    userChoice: question.options[userAnswer].text,
                    userChoiceScore: userOptionTotalScore,
                    betterChoice: question.options[bestOptionIndex].text,
                    betterChoiceScore: maxTotalScore,
                    description: question.description || "No description available"
                });
            }
        }
    }
    
    return missedQuestions;
}

// Save quiz result to localStorage
function saveQuizResult(quizData, userScores, finalScores, maxScores) {
    // Get current date
    var date = new Date();
    
    // Get quiz information
    var quizId = document.querySelector('.quiz-container').getAttribute('data-quiz-id') || 'unknown';
    var quizTitle = document.querySelector('.quiz-title').textContent || 'Quiz Result';
    
    // Collect questions to review
    var missedQuestions = collectMissedQuestions(quizData, userAnswers);
    
    // Create result object
    var result = {
        id: quizId,
        title: quizTitle,
        date: date.toLocaleString(),
        timestamp: date.getTime(),
        rawScores: JSON.parse(JSON.stringify(userScores)), // Deep copy
        finalScores: JSON.parse(JSON.stringify(finalScores)), // Deep copy
        maxScores: JSON.parse(JSON.stringify(maxScores)), // Deep copy
        missedQuestions: missedQuestions // Add questions to review
    };
    
    // Get history from localStorage
    var history = localStorage.getItem('quizHistory');
    var historyArray = history ? JSON.parse(history) : [];
    
    // Add new result to history
    historyArray.push(result);
    
    // Limit history size (keep most recent 20)
    if (historyArray.length > 20) {
        historyArray = historyArray.slice(historyArray.length - 20);
    }
    
    // Save history to localStorage
    localStorage.setItem('quizHistory', JSON.stringify(historyArray));
    
    // Update history dropdown menu
    updateHistoryDropdown();
}

// Show missed questions
function showMissedQuestions() {
    var missedQuestionsList = document.getElementById('missedQuestionsList');
    if (!missedQuestionsList) return;
    
    missedQuestionsList.innerHTML = '';
    
    var hasSuboptimalAnswers = false;
    
    // Loop through all questions
    for (var i = 0; i < quizData.questions.length; i++) {
        var question = quizData.questions[i];
        var userAnswer = userAnswers[i];
        
        if (userAnswer !== undefined) {
            // Calculate total score for user's chosen option
            var userOptionTotalScore = 0;
            var userOption = question.options[userAnswer];
            for (var category in userOption.scores) {
                if (userOption.scores.hasOwnProperty(category)) {
                    userOptionTotalScore += userOption.scores[category];
                }
            }
            
            // Find the highest scoring option for this question
            var maxTotalScore = -Infinity;
            var bestOptionIndex = -1;
            
            for (var j = 0; j < question.options.length; j++) {
                var option = question.options[j];
                var optionTotalScore = 0;
                
                for (var category in option.scores) {
                    if (option.scores.hasOwnProperty(category)) {
                        optionTotalScore += option.scores[category];
                    }
                }
                
                if (optionTotalScore > maxTotalScore) {
                    maxTotalScore = optionTotalScore;
                    bestOptionIndex = j;
                }
            }
            
            if (bestOptionIndex !== userAnswer) {
                hasSuboptimalAnswers = true;
                var missedQuestionItem = document.createElement('div');
                missedQuestionItem.className = 'missed-question-item';
                
                var questionText = document.createElement('div');
                questionText.className = 'missed-question-text';
                questionText.textContent = question.text;
                
                var userAnswerText = document.createElement('div');
                userAnswerText.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
                userAnswerText.innerHTML = '<strong>Your choice:</strong> ' + question.options[userAnswer].text + ' (Total score: ' + userOptionTotalScore + ')';
                
                var betterAnswerText = document.createElement('div');
                betterAnswerText.className = 'correct-answer';
                betterAnswerText.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
                betterAnswerText.innerHTML = '<strong>Better choice:</strong> ' + question.options[bestOptionIndex].text + ' (Total score: ' + maxTotalScore + ')';
                
                var questionDescription = document.createElement('div');
                questionDescription.className = 'question-description';
                questionDescription.textContent = question.description || "No description available";
                
                missedQuestionItem.appendChild(questionText);
                missedQuestionItem.appendChild(userAnswerText);
                missedQuestionItem.appendChild(betterAnswerText);
                missedQuestionItem.appendChild(questionDescription);
                
                missedQuestionsList.appendChild(missedQuestionItem);
            }
        }
    }
    
    // If all user choices are the best option
    if (!hasSuboptimalAnswers) {
        var perfectScore = document.createElement('div');
        perfectScore.textContent = 'Congratulations! You chose the highest scoring option in all questions.';
        perfectScore.style.textAlign = 'center';
        perfectScore.style.padding = '20px';
        perfectScore.style.fontWeight = 'bold';
        perfectScore.style.color = '#28a745';
        missedQuestionsList.appendChild(perfectScore);
    }
}

// Show areas that need improvement
function showImprovementAreas(finalScores) {
    var improvementList = document.getElementById('improvementList');
    if (!improvementList) return;
    
    improvementList.innerHTML = '';
    
    var scoreTypes = {
        awareness: 'Understanding of online threats',
        confidence: 'Confidence in handling online situations',
        habits: 'Safe online habits',
        support: 'Helping your child use the internet wisely',
        trust: 'Critical evaluation of online content',
        preparedness: 'Preparedness for online challenges'
    };
    
    // Determine areas for improvement based on final score (scores below 7)
    var hasImprovementAreas = false;
    for (var scoreType in finalScores) {
        if (finalScores.hasOwnProperty(scoreType) && finalScores[scoreType] < 7) {
            hasImprovementAreas = true;
            createImprovementItem(scoreType, finalScores[scoreType], scoreTypes[scoreType], improvementList);
        }
    }
    
    if (!hasImprovementAreas) {
        var listItem = document.createElement('li');
        listItem.innerHTML = '<h4 style="color: #28a745; font-weight: bold;">Great job!</h4><p>You are performing excellently in all security areas. Continue maintaining these good habits, and consider:</p><ul><li>Sharing your cybersecurity knowledge with family and friends</li><li>Staying updated on the latest security trends</li><li>Exploring advanced security technologies and methods</li><li>Participating in cybersecurity communities and discussions</li></ul>';
        improvementList.appendChild(listItem);
    }
}

// Create improvement item
function createImprovementItem(scoreType, score, title, container) {
    var improvementSuggestions = getImprovementSuggestions();
    var listItem = document.createElement('li');
    var categoryTitle = document.createElement('h4');
    categoryTitle.style.fontWeight = 'bold';
    categoryTitle.style.color = '#212529';
    categoryTitle.textContent = title;
    
    var suggestionDiv = document.createElement('div');
    if (score < 3) {
        suggestionDiv.innerHTML = improvementSuggestions[scoreType].low;
    } else if (score < 7) {
        suggestionDiv.innerHTML = improvementSuggestions[scoreType].medium;
    } else {
        suggestionDiv.innerHTML = improvementSuggestions[scoreType].high;
    }
    
    listItem.appendChild(categoryTitle);
    listItem.appendChild(suggestionDiv);
    container.appendChild(listItem);
}

// Get improvement suggestions
function getImprovementSuggestions() {
    return {
        awareness: {
            low: 'Your awareness of online threats needs improvement. Suggestions: <ul><li>Learn about common phishing techniques and social engineering attacks</li><li>Learn to identify signs of malware and ransomware</li><li>Stay updated on the latest cybersecurity threat trends</li><li>Participate in basic network security courses or seminars</li></ul>',
            medium: 'You have a basic understanding of online threats, but there\'s room for improvement. Suggestions: <ul><li>Learn more about advanced phishing techniques</li><li>Learn how to identify fake websites and applications</li><li>Understand the risks and impacts of data breaches</li></ul>',
            high: 'You have a good understanding of online threats. Stay vigilant and: <ul><li>Regularly update your security knowledge</li><li>Learn about threats that emerging technologies might bring</li><li>Consider sharing your knowledge with family</li></ul>'
        },
        confidence: {
            low: 'You lack confidence in handling online situations. Suggestions: <ul><li>Start with simple security practices like updating passwords and enabling two-factor authentication</li><li>Gradually learn basic privacy setting adjustment methods</li><li>Seek help from trusted individuals to resolve questions</li><li>Use security check tools to assess your online accounts</li></ul>',
            medium: 'You have some confidence in handling online situations. Continue to strengthen: <ul><li>Try handling more complex security settings</li><li>Learn how to safely recover compromised accounts</li><li>Develop the ability to solve common security issues</li></ul>',
            high: 'You are confident in handling online situations. Continue to: <ul><li>Challenge yourself with more complex security scenarios</li><li>Help others improve their online confidence</li><li>Regularly test your security response capabilities</li></ul>'
        },
        habits: {
            low: 'Your online safety habits need improvement. Suggestions: <ul><li>Develop habits of regularly updating software and applications</li><li>Use password managers to create and store strong passwords</li><li>Enable two-factor authentication for important accounts</li><li>Use VPN when using public Wi-Fi</li><li>Regularly backup important data</li></ul>',
            medium: 'You have some good security habits, but can further improve: <ul><li>Establish personal security check routines</li><li>Increase password complexity and change them regularly</li><li>Value privacy settings and check them regularly</li></ul>',
            high: 'You have excellent security habits. Keep it up and: <ul><li>Automate certain security processes, such as automatic updates and backups</li><li>Regularly review your digital footprint</li><li>Develop sensitivity to abnormal activities</li></ul>'
        },
        support: {
            low: 'You need to improve in helping children use the internet safely. Suggestions: <ul><li>Learn the basics of online safety for children</li><li>Learn to set up parental controls and content filters</li><li>Establish open communication channels with children to discuss online experiences</li><li>Set clear family internet usage rules</li></ul>',
            medium: 'You\'re doing well in supporting children\'s online safety. Continue to strengthen: <ul><li>Explore new applications and websites with your children</li><li>Discuss the importance of privacy settings and data sharing</li><li>Teach the ability to identify inappropriate content and contacts</li></ul>',
            high: 'You excel in supporting children\'s online safety. Continue to: <ul><li>Regularly update your guidance methods to adapt to new online trends</li><li>Develop children\'s digital literacy and critical thinking</li><li>Establish a family digital well-being plan</li></ul>'
        },
        trust: {
            low: 'You need to improve in evaluating the credibility of online content. Suggestions: <ul><li>Learn basic skills to identify fake news and misleading information</li><li>Understand common manipulation and propaganda techniques</li><li>Check multiple reliable sources before verifying information</li><li>Be wary of emotional and extreme content</li></ul>',
            medium: 'You have some critical evaluation abilities for online content. Continue to improve: <ul><li>Learn more about confirmation bias and its effects</li><li>Learn advanced methods for evaluating source reliability</li><li>Develop the ability to identify subtle misleading information</li></ul>',
            high: 'You have strong critical thinking in evaluating online content. Continue to: <ul><li>Share your analytical skills with others</li><li>Explore more complex information manipulation strategies</li><li>Regularly check your own information consumption habits</li></ul>'
        },
        preparedness: {
            low: 'You are underprepared for cyber security challenges. Suggestions: <ul><li>Create a security incident response plan</li><li>Learn how to identify signs of account compromise</li><li>Learn how to safely reset compromised accounts</li><li>Save important contacts and resources for use in security issues</li></ul>',
            medium: 'You have some preparation for security challenges. Continue to strengthen: <ul><li>Regularly test and update your response plan</li><li>Learn more complex security recovery processes</li><li>Establish data recovery strategies</li></ul>',
            high: 'You are well-prepared for cyber security challenges. Continue to: <ul><li>Explore advanced security measures and recovery strategies</li><li>Consider conducting security drills to test your preparedness</li><li>Develop personalized risk assessment methods</li></ul>'
        }
    };
}

// Update score display
function updateScoreDisplay(finalScores) {
    Object.keys(finalScores).forEach(function(category) {
        var score = finalScores[category];
        var element = document.getElementById(category + 'Score');
        if (!element) return;
        
        element.textContent = score.toFixed(1);
        
        // Set color based on score range
        if (score >= 7) {
            element.className = 'score-value positive';
        } else if (score >= 4) {
            element.className = 'score-value neutral';
        } else {
            element.className = 'score-value negative';
        }
    });
}

// Update score explanation table
function updateScoreExplanation(scores, maxScores) {
    Object.keys(scores).forEach(function(category) {
        var element = document.getElementById(category + 'ScoreExplanation');
        if (!element) return;
        
        element.textContent = scores[category] + " / " + maxScores[category];
        
        // Set score color
        if (scores[category] > 0) {
            element.className = 'user-score positive-score';
        } else if (scores[category] < 0) {
            element.className = 'user-score negative-score';
        } else {
            element.className = 'user-score neutral-score';
        }
    });
}

// Update debug information
function updateDebugInfo(scores, maxScores) {
    var debugInfo = document.getElementById('scoreDebugInfo');
    if (!debugInfo) return;
    
    var html = '';
    
    Object.keys(scores).forEach(function(category) {
        var categoryName = '';
        switch(category) {
            case 'awareness': categoryName = 'Awareness'; break;
            case 'confidence': categoryName = 'Confidence'; break;
            case 'habits': categoryName = 'Habits'; break;
            case 'support': categoryName = 'Support'; break;
            case 'trust': categoryName = 'Trust'; break;
            case 'preparedness': categoryName = 'Preparedness'; break;
        }
        
        html += '<p><strong>' + categoryName + ':</strong> ' + scores[category] + ' / ' + maxScores[category] + '</p>';
    });
    
    debugInfo.innerHTML = html;
}

// Load history item and display in modal
function loadHistoryItem(result) {
    console.log('Loading history item:', result);
    
    // Set modal title and date
    document.getElementById('historyModalTitle').textContent = result.title;
    document.getElementById('historyModalDate').textContent = 'Completed on: ' + result.date;
    
    // Generate radar chart
    createHistoryRadarChart(result.finalScores);
    
    // Fill score table
    var tableBody = document.getElementById('historyScoreTableBody');
    tableBody.innerHTML = '';
    
    var categories = {
        awareness: 'Awareness',
        confidence: 'Confidence',
        habits: 'Habits',
        support: 'Support',
        trust: 'Trust',
        preparedness: 'Preparedness'
    };
    
    for (var category in categories) {
        if (result.finalScores.hasOwnProperty(category)) {
            var row = document.createElement('tr');
            
            var categoryCell = document.createElement('td');
            categoryCell.className = 'score-category';
            categoryCell.textContent = categories[category];
            categoryCell.style.fontWeight = '600';
            categoryCell.style.color = '#212529';
            
            var rawScoreCell = document.createElement('td');
            rawScoreCell.textContent = result.rawScores[category];
            rawScoreCell.style.color = '#333';
            
            var maxScoreCell = document.createElement('td');
            maxScoreCell.textContent = result.maxScores[category];
            maxScoreCell.style.color = '#333';
            
            var finalScoreCell = document.createElement('td');
            finalScoreCell.textContent = result.finalScores[category].toFixed(1);
            
            // Set color based on score
            if (result.finalScores[category] >= 7) {
                finalScoreCell.style.color = '#28a745';
                finalScoreCell.style.fontWeight = 'bold';
            } else if (result.finalScores[category] >= 4) {
                finalScoreCell.style.color = '#414141';
                finalScoreCell.style.fontWeight = 'bold';
            } else {
                finalScoreCell.style.color = '#dc3545';
                finalScoreCell.style.fontWeight = 'bold';
            }
            
            row.appendChild(categoryCell);
            row.appendChild(rawScoreCell);
            row.appendChild(maxScoreCell);
            row.appendChild(finalScoreCell);
            
            tableBody.appendChild(row);
        }
    }
    
    // Show areas that need improvement
    var improvementList = document.getElementById('historyImprovementList');
    improvementList.innerHTML = '';
    
    var scoreTypes = {
        awareness: 'Understanding of online threats',
        confidence: 'Confidence in handling online situations',
        habits: 'Safe online habits',
        support: 'Helping your child use the internet wisely',
        trust: 'Critical evaluation of online content',
        preparedness: 'Preparedness for online challenges'
    };
    
    // Determine areas for improvement based on final score (scores below 5)
    var hasImprovementAreas = false;
    for (var scoreType in result.finalScores) {
        if (result.finalScores.hasOwnProperty(scoreType) && result.finalScores[scoreType] < 5) {
            hasImprovementAreas = true;
            var listItem = document.createElement('li');
            listItem.textContent = scoreTypes[scoreType];
            listItem.style.color = '#333'; // Dark text for better readability
            listItem.style.marginBottom = '8px';
            improvementList.appendChild(listItem);
        }
    }
    
    if (!hasImprovementAreas) {
        var listItem = document.createElement('li');
        listItem.innerHTML = '<h4 style="color: #28a745; font-weight: bold;">Great job!</h4><p>You are performing excellently in all security areas. Continue maintaining these good habits, and consider:</p><ul><li>Sharing your cybersecurity knowledge with family and friends</li><li>Staying updated on the latest security trends</li><li>Exploring advanced security technologies and methods</li><li>Participating in cybersecurity communities and discussions</li></ul>';
        improvementList.appendChild(listItem);
    }
    
    // Show questions to review
    if (result.missedQuestions && result.missedQuestions.length > 0) {
        var missedQuestionsContainer = document.getElementById('historyMissedQuestionsList');
        missedQuestionsContainer.innerHTML = '';
        
        result.missedQuestions.forEach(function(missedQuestion) {
            var questionItem = document.createElement('div');
            questionItem.className = 'missed-question-item';
            questionItem.style.marginBottom = '20px';
            questionItem.style.padding = '15px';
            questionItem.style.backgroundColor = '#f8f9fa';
            questionItem.style.borderRadius = '5px';
            questionItem.style.border = '1px solid #ddd';
            
            var questionText = document.createElement('div');
            questionText.className = 'missed-question-text';
            questionText.textContent = missedQuestion.text;
            questionText.style.fontWeight = 'bold';
            questionText.style.marginBottom = '10px';
            questionText.style.color = '#212529'; // Dark text
            
            var userChoice = document.createElement('div');
            userChoice.style.color = '#212529 !important'; 
            userChoice.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
            userChoice.innerHTML = '<strong>Your choice:</strong> ' + missedQuestion.userChoice + 
                (missedQuestion.userChoiceScore ? ' (Total score: ' + missedQuestion.userChoiceScore + ')' : '');
            
            var betterChoice = document.createElement('div');
            betterChoice.className = 'correct-answer';
            betterChoice.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
            betterChoice.innerHTML = '<strong>Better choice:</strong> ' + missedQuestion.betterChoice + 
                (missedQuestion.betterChoiceScore ? ' (Total score: ' + missedQuestion.betterChoiceScore + ')' : '');
            
            var description = document.createElement('div');
            description.className = 'question-description';
            description.textContent = missedQuestion.description || 'No additional description';
            description.style.marginTop = '10px';
            description.style.color = '#495057'; // Medium-depth gray
            description.style.fontStyle = 'italic';
            
            questionItem.appendChild(questionText);
            questionItem.appendChild(userChoice);
            questionItem.appendChild(betterChoice);
            questionItem.appendChild(description);
            
            missedQuestionsContainer.appendChild(questionItem);
        });
    } else {
        var emptyMissed = document.createElement('div');
        emptyMissed.textContent = 'Congratulations! You chose the highest scoring option in all questions.';
        emptyMissed.style.textAlign = 'center';
        emptyMissed.style.padding = '20px';
        emptyMissed.style.fontWeight = 'bold';
        emptyMissed.style.color = '#28a745'; // Green but ensure readability
        document.getElementById('historyMissedQuestionsList').appendChild(emptyMissed);
    }
    
    // Show modal
    document.getElementById('historyModal').style.display = 'block';
    
    // Close dropdown menu
    document.querySelector('.menu-dropdown').classList.remove('active');
}

// Create history radar chart
function createHistoryRadarChart(finalScores) {
    createRadarChart(finalScores, 'historyRadarChart', 'historyChart');
}

// Create radar chart (general function)
function createRadarChart(scores, chartId, chartInstanceName) {
    var ctx = document.getElementById(chartId).getContext('2d');
    
    // Check if chart instance already exists, if so, destroy it
    if (window[chartInstanceName]) {
        window[chartInstanceName].destroy();
    }
    
    window[chartInstanceName] = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Awareness', 'Confidence', 'Habits', 'Support', 'Trust', 'Preparedness'],
            datasets: [
                {
                    label: 'Scores',
                    data: [
                        scores.awareness,
                        scores.confidence, 
                        scores.habits,
                        scores.support,
                        scores.trust,
                        scores.preparedness
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(54, 162, 235, 1)',
                    fill: true
                }
            ]
        },
        options: {
            elements: {
                line: {
                    borderWidth: 3
                }
            },
            scales: {
                r: {
                    angleLines: {
                        display: true,
                        color: 'rgba(0, 0, 0, 0.1)',
                        lineWidth: 1
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)',
                        circular: true
                    },
                    pointLabels: {
                        font: {
                            size: 14,
                            weight: 'bold'
                        },
                        color: '#333'
                    },
                    suggestedMin: 0,
                    suggestedMax: 10,
                    ticks: {
                        stepSize: 2,
                        backdropColor: 'transparent',
                        color: '#333',
                        font: {
                            weight: 'bold'
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: chartId === 'radarChart', // Only show legend on main radar chart
                    position: 'bottom',
                    labels: {
                        boxWidth: 15,
                        padding: 15,
                        font: {
                            size: 14,
                            weight: 'bold'
                        },
                        color: '#333'
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    titleFont: {
                        size: 14
                    },
                    bodyFont: {
                        size: 13
                    }
                }
            },
            layout: {
                padding: 20
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
} 