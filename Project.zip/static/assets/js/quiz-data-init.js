// Initialize quiz data from the server-rendered template
var quizData = window.quizData || {};
var totalQuestions = window.totalQuestions || 0;

// This script will be replaced by server-side logic that injects the actual quiz data
console.log("Quiz data initialized for detail page"); 