document.addEventListener('DOMContentLoaded', function() {
    // Image preview handler
    document.getElementById('quizImage').addEventListener('change', function(event) {
        var file = event.target.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                var previewImage = document.getElementById('previewImage');
                previewImage.src = e.target.result;
                previewImage.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });

    // Option management
    let optionCount = 2;
    
    document.getElementById('addOption').addEventListener('click', function() {
        if (optionCount < 10) {
            optionCount++;
            
            const optionsContainer = document.getElementById('optionsContainer');
            const newOption = document.createElement('div');
            newOption.className = 'option-container';
            newOption.innerHTML = `
                <input type="text" name="option${optionCount}" placeholder="Option ${optionCount}" required>
                <input type="number" name="score${optionCount}" min="0" max="100" placeholder="Score" required>
                <button type="button" class="remove-button" onclick="removeOption(this)">Remove</button>
            `;
            
            optionsContainer.appendChild(newOption);
        } else {
            alert('Maximum 10 options allowed');
        }
    });

    // Form submission
    document.getElementById('quizForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Collect form data
        const formData = new FormData(this);
        
        // Send form data to server
        fetch('/admin/create-quiz', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Quiz created successfully!');
                window.location.reload();
            } else {
                alert('Error creating quiz: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    });

    // Delete quiz functionality
    const deleteButtons = document.querySelectorAll('.delete-quiz-button');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const quizId = this.getAttribute('data-id');
            
            if (confirm('Are you sure you want to delete this quiz?')) {
                fetch(`/admin/delete-quiz/${quizId}`, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove the quiz item from the DOM
                        this.closest('.quiz-item').remove();
                        alert('Quiz deleted successfully!');
                    } else {
                        alert('Error deleting quiz: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
            }
        });
    });
});

// Remove option function (needs to be global for the onclick handler)
function removeOption(button) {
    button.parentElement.remove();
}

let questionCount = 1;

function addQuestion() {
    questionCount++;
    const questionsContainer = document.getElementById('questionsContainer');
    const newQuestion = document.createElement('div');
    newQuestion.className = 'question-container';
    newQuestion.setAttribute('data-question-id', questionCount);
    
    newQuestion.innerHTML = `
        <div class="form-group">
            <label>Question ${questionCount}</label>
            <input type="text" name="question${questionCount}" required placeholder="Enter your question here">
        </div>
        <div class="form-group">
            <label>Hint (Optional)</label>
            <textarea name="questionHint${questionCount}" placeholder="Enter hint content to help users understand the question"></textarea>
        </div>
        <div class="form-group">
            <label>Description (Optional)</label>
            <textarea name="questionDescription${questionCount}" placeholder="Enter question description, will be displayed on the results page"></textarea>
        </div>
        <div class="options-container">
            <div class="option-container">
                <input type="text" name="option${questionCount}_1" placeholder="Enter option 1 text" required>
                <div class="rating-container">
                    <div class="rating-item">
                        <label>Awareness</label>
                        <select name="awareness${questionCount}_1" required>
                            <option value="">Select Awareness Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Confidence</label>
                        <select name="confidence${questionCount}_1" required>
                            <option value="">Select Confidence Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Habits</label>
                        <select name="habits${questionCount}_1" required>
                            <option value="">Select Habits Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Support</label>
                        <select name="support${questionCount}_1" required>
                            <option value="">Select Support Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Trust</label>
                        <select name="trust${questionCount}_1" required>
                            <option value="">Select Trust Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Preparedness</label>
                        <select name="preparedness${questionCount}_1" required>
                            <option value="">Select Preparedness Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="option-container">
                <input type="text" name="option${questionCount}_2" placeholder="Enter option 2 text" required>
                <div class="rating-container">
                    <div class="rating-item">
                        <label>Awareness</label>
                        <select name="awareness${questionCount}_2" required>
                            <option value="">Select Awareness Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Confidence</label>
                        <select name="confidence${questionCount}_2" required>
                            <option value="">Select Confidence Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Habits</label>
                        <select name="habits${questionCount}_2" required>
                            <option value="">Select Habits Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Support</label>
                        <select name="support${questionCount}_2" required>
                            <option value="">Select Support Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Trust</label>
                        <select name="trust${questionCount}_2" required>
                            <option value="">Select Trust Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="rating-item">
                        <label>Preparedness</label>
                        <select name="preparedness${questionCount}_2" required>
                            <option value="">Select Preparedness Score</option>
                            <option value="-5">-5</option>
                            <option value="-4">-4</option>
                            <option value="-3">-3</option>
                            <option value="-2">-2</option>
                            <option value="-1">-1</option>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <button type="button" class="add-button" onclick="addOption(${questionCount})">Add Option</button>
        <button type="button" class="remove-button" onclick="removeQuestion(${questionCount})">Remove Question</button>
    `;
    
    questionsContainer.appendChild(newQuestion);
}

function addOption(questionId) {
    const questionContainer = document.querySelector(`[data-question-id="${questionId}"]`);
    const optionsContainer = questionContainer.querySelector('.options-container');
    const optionCount = optionsContainer.children.length + 1;
    
    const newOption = document.createElement('div');
    newOption.className = 'option-container';
    newOption.innerHTML = `
        <div style="width: 100%;">
            <input type="text" name="option${questionId}_${optionCount}" placeholder="Enter option ${optionCount} text" required style="width: 100%; margin-bottom: 1rem;">
            <div class="rating-container">
                <div class="rating-item">
                    <label>Awareness</label>
                    <select name="awareness${questionId}_${optionCount}" required>
                        <option value="">Select Awareness Score</option>
                        <option value="-5">-5</option>
                        <option value="-4">-4</option>
                        <option value="-3">-3</option>
                        <option value="-2">-2</option>
                        <option value="-1">-1</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="rating-item">
                    <label>Confidence</label>
                    <select name="confidence${questionId}_${optionCount}" required>
                        <option value="">Select Confidence Score</option>
                        <option value="-5">-5</option>
                        <option value="-4">-4</option>
                        <option value="-3">-3</option>
                        <option value="-2">-2</option>
                        <option value="-1">-1</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="rating-item">
                    <label>Habits</label>
                    <select name="habits${questionId}_${optionCount}" required>
                        <option value="">Select Habits Score</option>
                        <option value="-5">-5</option>
                        <option value="-4">-4</option>
                        <option value="-3">-3</option>
                        <option value="-2">-2</option>
                        <option value="-1">-1</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="rating-item">
                    <label>Support</label>
                    <select name="support${questionId}_${optionCount}" required>
                        <option value="">Select Support Score</option>
                        <option value="-5">-5</option>
                        <option value="-4">-4</option>
                        <option value="-3">-3</option>
                        <option value="-2">-2</option>
                        <option value="-1">-1</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="rating-item">
                    <label>Trust</label>
                    <select name="trust${questionId}_${optionCount}" required>
                        <option value="">Select Trust Score</option>
                        <option value="-5">-5</option>
                        <option value="-4">-4</option>
                        <option value="-3">-3</option>
                        <option value="-2">-2</option>
                        <option value="-1">-1</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="rating-item">
                    <label>Preparedness</label>
                    <select name="preparedness${questionId}_${optionCount}" required>
                        <option value="">Select Preparedness Score</option>
                        <option value="-5">-5</option>
                        <option value="-4">-4</option>
                        <option value="-3">-3</option>
                        <option value="-2">-2</option>
                        <option value="-1">-1</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
            </div>
        </div>
        <button type="button" class="remove-button" onclick="removeOption(this)">Remove</button>
    `;
    
    optionsContainer.appendChild(newOption);
}

function removeQuestion(questionId) {
    const questionContainer = document.querySelector(`[data-question-id="${questionId}"]`);
    questionContainer.remove();
}

function previewImage(input) {
    const preview = document.getElementById('preview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Form submission
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('questionForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        fetch('/save_question', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Quiz saved successfully!');
                window.location.href = '/question';
            } else {
                alert('Error saving quiz: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while saving the quiz.');
        });
    });

    // Load existing quizzes
    fetchExistingQuizzes();
});

function fetchExistingQuizzes() {
    fetch('/get_quizzes')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayExistingQuizzes(data.quizzes);
            } else {
                document.getElementById('existing-quizzes-container').innerHTML = 
                    '<p>Failed to load quiz data: ' + data.message + '</p>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('existing-quizzes-container').innerHTML = 
                '<p>Error loading quiz data</p>';
        });
}

function displayExistingQuizzes(quizzes) {
    var container = document.getElementById('existing-quizzes-container');
    
    if (quizzes.length === 0) {
        container.innerHTML = '<p>No quizzes available</p>';
        return;
    }
    
    var html = '<div class="quiz-grid">';
    
    for (var i = 0; i < quizzes.length; i++) {
        var quiz = quizzes[i];
        var quizImage = quiz.image ? '/static/' + quiz.image : '/static/images/default-quiz.png';
        
        html += `
            <div class="quiz-item">
                <div class="quiz-image">
                    <img src="${quizImage}" alt="${quiz.title}" onerror="this.src='/static/images/default-quiz.png'">
                </div>
                <div class="quiz-info">
                    <h3>${quiz.title}</h3>
                    <p>${quiz.description || 'No description'}</p>
                    <button class="delete-quiz-button" onclick="deleteQuiz('${quiz.id}')">Delete</button>
                </div>
            </div>
        `;
    }
    
    html += '</div>';
    container.innerHTML = html;
}

function deleteQuiz(quizId) {
    if (confirm('Are you sure you want to delete this quiz? This action cannot be undone.')) {
        fetch('/delete_quiz/' + quizId, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Quiz deleted successfully!');
                fetchExistingQuizzes();
            } else {
                alert('Failed to delete quiz: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error deleting quiz');
        });
    }
} 