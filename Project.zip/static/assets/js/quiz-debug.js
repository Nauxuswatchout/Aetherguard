// Simple debug script to test quiz functionality
console.log("Debug script loaded!");

// Initialize score variables
var userScores = {
    awareness: 0,
    confidence: 0,
    habits: 0,
    support: 0,
    trust: 0,
    preparedness: 0
};
var userAnswers = [];
var debugLog = []; // For tracking score calculations

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM fully loaded - Debug mode active");
    
    // Check if quiz data is available
    if (typeof quizData !== 'undefined' && typeof totalQuestions !== 'undefined') {
        console.log("Quiz data found:", quizData);
        console.log("Total questions:", totalQuestions);
    } else {
        console.error("Error: Quiz data not found!");
    }
    
    // Get start button
    const startButton = document.getElementById('startQuiz');
    
    if (startButton) {
        console.log("Start button found:", startButton);
        
        // Add click event to start button
        startButton.addEventListener('click', function() {
            console.log("Start button clicked!");
            
            const quizHeader = document.querySelector('.quiz-header');
            const questionContainer = document.getElementById('questionContainer');
            
            console.log("Quiz header visibility before:", quizHeader.style.display);
            console.log("Question container visibility before:", questionContainer.style.display);
            
            // Hide quiz header and show question container
            if (quizHeader) {
                quizHeader.style.display = 'none';
                console.log("Quiz header hidden");
            } else {
                console.error("Quiz header not found!");
            }
            
            if (questionContainer) {
                questionContainer.style.display = 'block';
                console.log("Question container shown");
            } else {
                console.error("Question container not found!");
            }
            
            console.log("Quiz header visibility after:", quizHeader.style.display);
            console.log("Question container visibility after:", questionContainer.style.display);
            
            // Show first question
            showFirstQuestion();
        });
    } else {
        console.error("Error: Start button not found!");
    }
    
    // Function to show the first question
    function showFirstQuestion() {
        console.log("Attempting to show first question");
        
        const questionBoxes = document.querySelectorAll('.question-box');
        console.log("Found question boxes:", questionBoxes.length);
        
        if (questionBoxes.length > 0) {
            // Hide all questions first
            questionBoxes.forEach(box => {
                box.style.display = 'none';
                console.log("Question box hidden:", box.id);
            });
            
            // Show the first question
            const firstQuestion = document.getElementById('question1');
            if (firstQuestion) {
                firstQuestion.style.display = 'block';
                console.log("First question displayed:", firstQuestion.id);
            } else {
                console.error("Error: First question element not found!");
            }
        } else {
            console.error("Error: No question boxes found!");
        }
    }
    
    // Initialize hint buttons
    const hintButtons = document.querySelectorAll('.get-hint-button');
    console.log("Found hint buttons:", hintButtons.length);
    
    hintButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            console.log("Hint button clicked for question:", this.getAttribute('data-question'));
            this.classList.toggle('flipped');
        });
    });
    
    // Also add event listeners to options
    const optionItems = document.querySelectorAll('.option-item');
    console.log("Found option items:", optionItems.length);
    
    optionItems.forEach(function(option) {
        option.addEventListener('click', function() {
            // Get the active question box (the one being displayed)
            const activeQuestionBox = document.querySelector('.question-box[style*="display: block"]');
            if (!activeQuestionBox) {
                console.error("No active question box found!");
                return;
            }
            
            // Get the question index and current question number
            const questionIndex = parseInt(activeQuestionBox.getAttribute('data-question-index'));
            const currentQuestionNum = parseInt(document.getElementById('currentQuestionNumber').textContent);
            
            // Get the option index
            const optionIndex = parseInt(this.getAttribute('data-option-index'));
            
            console.log("Option clicked - Question Index:", questionIndex, "Question Number:", currentQuestionNum, "Option Index:", optionIndex);
            
            // Remove selected class from all options in the active question
            const allOptionsInQuestion = activeQuestionBox.querySelectorAll('.option-item');
            allOptionsInQuestion.forEach(opt => opt.classList.remove('selected'));
            
            // Add selected class to the clicked option
            this.classList.add('selected');
            
            // Update scores
            if (quizData && 
                quizData.questions && 
                quizData.questions[questionIndex] && 
                quizData.questions[questionIndex].options && 
                quizData.questions[questionIndex].options[optionIndex] &&
                quizData.questions[questionIndex].options[optionIndex].scores) {
                
                const optionScores = quizData.questions[questionIndex].options[optionIndex].scores;
                console.log("Option scores:", optionScores);
                
                // Debug log for score calculation
                let scoreLog = {
                    questionIndex: questionIndex,
                    questionText: quizData.questions[questionIndex].text,
                    optionIndex: optionIndex,
                    optionText: quizData.questions[questionIndex].options[optionIndex].text,
                    scores: {}
                };
                
                // Update user scores
                for (let scoreType in optionScores) {
                    if (optionScores.hasOwnProperty(scoreType)) {
                        userScores[scoreType] += optionScores[scoreType];
                        console.log(`Updated ${scoreType} score to:`, userScores[scoreType]);
                        scoreLog.scores[scoreType] = optionScores[scoreType];
                    }
                }
                
                debugLog.push(scoreLog);
                
                // Store user answers - indexed by current question index
                userAnswers[questionIndex] = {
                    questionIndex: questionIndex,
                    optionIndex: optionIndex,
                    questionNumber: currentQuestionNum
                };
                console.log("User answers updated:", userAnswers);
            } else {
                console.error("Cannot find or access option scores. Quiz data structure may be incorrect.");
                console.log("Quiz data structure:", quizData);
            }
            
            // Get next question
            const nextQuestion = document.getElementById('question' + (currentQuestionNum + 1));
            
            console.log("Current question element:", activeQuestionBox);
            console.log("Next question element:", nextQuestion);
            
            // Delay 500ms before moving to the next question
            setTimeout(function() {
                // Hide current question
                if (activeQuestionBox) {
                    activeQuestionBox.style.display = 'none';
                    console.log("Current question hidden");
                }
                
                // If there is a next question, show it
                if (nextQuestion) {
                    nextQuestion.style.display = 'block';
                    document.getElementById('currentQuestionNumber').textContent = currentQuestionNum + 1;
                    console.log("Next question shown:", nextQuestion.id);
                    
                    // Update progress bar
                    const progressPercentage = (currentQuestionNum / totalQuestions) * 100;
                    document.getElementById('progressBar').style.width = progressPercentage + '%';
                    document.getElementById('progressPercentage').textContent = Math.round(progressPercentage);
                    console.log("Progress updated:", progressPercentage + "%");
                } else {
                    console.log("No next question - Quiz complete");
                    // Show results
                    document.getElementById('questionContainer').style.display = 'none';
                    document.getElementById('resultsContainer').style.display = 'block';
                    console.log("Results container shown");
                    
                    // Calculate and show results
                    showResults();
                }
            }, 500);
        });
    });
    
    // Initialize restart button
    const restartButton = document.getElementById('restartQuiz');
    if (restartButton) {
        restartButton.addEventListener('click', function() {
            console.log("Restart button clicked");
            restartQuiz();
        });
    }
    
    // Show results function
    function showResults() {
        console.log("Showing results");
        
        try {
            // Calculate max possible scores
            const categoryMaxScores = {};
            
            // Calculate maximum possible scores by summing the highest score for each category in each question
            quizData.questions.forEach((question, questionIndex) => {
                if (question.options && Array.isArray(question.options)) {
                    // Track best scores for each category in this question
                    const questionBestScores = {};
                    
                    // Find the highest score for each category
                    question.options.forEach(option => {
                        if (option.scores) {
                            for (let category in option.scores) {
                                if (!questionBestScores[category] || option.scores[category] > questionBestScores[category]) {
                                    questionBestScores[category] = option.scores[category];
                                }
                            }
                        }
                    });
                    
                    // Add each category's best score to the total
                    for (let category in questionBestScores) {
                        if (!categoryMaxScores[category]) {
                            categoryMaxScores[category] = 0;
                        }
                        
                        // Only add positive scores to max possible
                        if (questionBestScores[category] > 0) {
                            categoryMaxScores[category] += questionBestScores[category];
                        }
                    }
                    
                    console.log(`Question ${questionIndex+1} best scores:`, questionBestScores);
                }
            });
            
            // If no max scores were found, use default values
            if (Object.keys(categoryMaxScores).length === 0) {
                categoryMaxScores.awareness = totalQuestions * 5;
                categoryMaxScores.confidence = totalQuestions * 5;
                categoryMaxScores.habits = totalQuestions * 5;
                categoryMaxScores.support = totalQuestions * 5;
                categoryMaxScores.trust = totalQuestions * 5;
                categoryMaxScores.preparedness = totalQuestions * 5;
            }
            
            console.log("Max possible scores:", categoryMaxScores);
            console.log("User raw scores:", userScores);
            console.log("Score calculation log:", debugLog);
            
            // Calculate final normalized scores (0-10 range)
            const finalScores = {
                awareness: calculateFinalScore(userScores.awareness, categoryMaxScores.awareness),
                confidence: calculateFinalScore(userScores.confidence, categoryMaxScores.confidence),
                habits: calculateFinalScore(userScores.habits, categoryMaxScores.habits),
                support: calculateFinalScore(userScores.support, categoryMaxScores.support),
                trust: calculateFinalScore(userScores.trust, categoryMaxScores.trust),
                preparedness: calculateFinalScore(userScores.preparedness, categoryMaxScores.preparedness)
            };
            
            console.log("Final normalized scores:", finalScores);
            
            // Update score display
            updateScoreDisplay(finalScores);
            
            // Update score explanation table
            updateScoreExplanation(userScores, categoryMaxScores);
            
            // Show improvement areas
            showImprovementAreas(finalScores);
            
            // Show missed questions
            showMissedQuestions();
            
            // Create radar chart
            createRadarChart(finalScores);
            
            // Collect missed questions for history
            const missedQuestions = collectMissedQuestions();
            
            // Save result to history - Use the external history function if available
            if (typeof saveQuizResult === 'function') {
                saveQuizResult(quizData, userScores, finalScores, categoryMaxScores, missedQuestions);
                console.log("Quiz result saved to history");
            } else {
                console.warn("History function not available - results not saved");
            }
            
            console.log("Results displayed successfully");
        } catch (error) {
            console.error("Error showing results:", error);
        }
    }
    
    // Collect missed questions for history
    function collectMissedQuestions() {
        const missedQuestions = [];
        
        // Loop through all questions in the quiz
        for (let i = 0; i < quizData.questions.length; i++) {
            const question = quizData.questions[i];
            const userAnswerData = userAnswers[i];
            
            if (userAnswerData) {
                const optionIndex = userAnswerData.optionIndex;
                
                // Calculate total score of user's selected option
                let userOptionTotalScore = 0;
                const userOption = question.options[optionIndex];
                for (let category in userOption.scores) {
                    if (userOption.scores.hasOwnProperty(category)) {
                        userOptionTotalScore += userOption.scores[category];
                    }
                }
                
                // Find option with the highest score
                let maxTotalScore = -Infinity;
                let bestOptionIndex = -1;
                
                for (let j = 0; j < question.options.length; j++) {
                    const option = question.options[j];
                    let optionTotalScore = 0;
                    
                    for (let category in option.scores) {
                        if (option.scores.hasOwnProperty(category)) {
                            optionTotalScore += option.scores[category];
                        }
                    }
                    
                    if (optionTotalScore > maxTotalScore) {
                        maxTotalScore = optionTotalScore;
                        bestOptionIndex = j;
                    }
                }
                
                // If user didn't select the highest scoring option, add to missed questions
                if (bestOptionIndex !== optionIndex) {
                    missedQuestions.push({
                        text: question.text,
                        userChoice: question.options[optionIndex].text,
                        userChoiceScore: userOptionTotalScore,
                        betterChoice: question.options[bestOptionIndex].text,
                        betterChoiceScore: maxTotalScore,
                        description: question.description || "No description available"
                    });
                }
            }
        }
        
        return missedQuestions;
    }
    
    // Calculate final score (0-10 range)
    function calculateFinalScore(actualScore, maxPossibleScore) {
        console.log(`Calculating final score for actual=${actualScore}, max=${maxPossibleScore}`);
        
        // For negative scores, return 0
        if (actualScore < 0) {
            return 0;
        }
        
        // If max possible score is 0, return middle value 5
        if (maxPossibleScore === 0) {
            return 5;
        }
        
        // Calculate score ratio
        const scoreRatio = actualScore / maxPossibleScore;
        
        // For scores close to 0.5, return 5
        if (Math.abs(scoreRatio - 0.5) < 0.01) {
            return 5;
        }
        
        // Map ratio to 0-10 range, ensuring it doesn't exceed 10
        const normalizedScore = Math.min(scoreRatio * 10, 10);
        console.log(`Normalized score: ${normalizedScore}`);
        return normalizedScore;
    }
    
    // Restart quiz
    function restartQuiz() {
        console.log("Restarting quiz");
        
        // Reset scores
        for (let scoreType in userScores) {
            if (userScores.hasOwnProperty(scoreType)) {
                userScores[scoreType] = 0;
            }
        }
        
        // Reset answers and debug log
        userAnswers = [];
        debugLog = [];
        
        // Remove selected class from all options
        const selectedOptions = document.querySelectorAll('.option-item.selected');
        selectedOptions.forEach(option => option.classList.remove('selected'));
        
        // Hide results and question container, show quiz header
        const resultsContainer = document.getElementById('resultsContainer');
        const quizHeader = document.querySelector('.quiz-header');
        const questionContainer = document.getElementById('questionContainer');
        
        if (resultsContainer) {
            resultsContainer.style.display = 'none';
        }
        
        if (quizHeader) {
            quizHeader.style.display = 'block';
        }
        
        if (questionContainer) {
            questionContainer.style.display = 'none';
        }
        
        // Reset progress bar and question number
        document.getElementById('currentQuestionNumber').textContent = '1';
        document.getElementById('progressBar').style.width = '0%';
        document.getElementById('progressPercentage').textContent = '0';
        
        console.log("Quiz restarted successfully");
    }
    
    // Update score display
    function updateScoreDisplay(finalScores) {
        console.log("Updating score display with:", finalScores);
        
        try {
            // Update score displays
            document.getElementById('awarenessScore').textContent = finalScores.awareness.toFixed(1);
            document.getElementById('confidenceScore').textContent = finalScores.confidence.toFixed(1);
            document.getElementById('habitsScore').textContent = finalScores.habits.toFixed(1);
            document.getElementById('supportScore').textContent = finalScores.support.toFixed(1);
            document.getElementById('trustScore').textContent = finalScores.trust.toFixed(1);
            document.getElementById('preparednessScore').textContent = finalScores.preparedness.toFixed(1);
            
            // Set score colors based on value
            for (let category in finalScores) {
                const scoreElement = document.getElementById(category + 'Score');
                const score = finalScores[category];
                
                if (scoreElement) {
                    // Clear existing classes
                    scoreElement.classList.remove('high-score', 'medium-score', 'low-score');
                    
                    // Add appropriate class
                    if (score >= 7) {
                        scoreElement.classList.add('high-score');
                    } else if (score >= 4) {
                        scoreElement.classList.add('medium-score');
                    } else {
                        scoreElement.classList.add('low-score');
                    }
                }
            }
            
            console.log("Score display updated successfully");
        } catch (error) {
            console.error("Error updating score display:", error);
        }
    }
    
    // Update score explanation table
    function updateScoreExplanation(userScores, categoryMaxScores) {
        console.log("Updating score explanation table");
        
        try {
            // Update scores in the table
            for (let category in userScores) {
                if (userScores.hasOwnProperty(category)) {
                    const element = document.getElementById(category + 'ScoreExplanation');
                    if (element) {
                        element.textContent = userScores[category] + " / " + categoryMaxScores[category];
                        
                        // Set score color
                        if (userScores[category] > 0) {
                            element.className = 'user-score positive-score';
                        } else if (userScores[category] < 0) {
                            element.className = 'user-score negative-score';
                        } else {
                            element.className = 'user-score neutral-score';
                        }
                    }
                }
            }
            
            // Enable debug info display
            const debugInfoSection = document.querySelector('.debug-info');
            if (debugInfoSection) {
                debugInfoSection.style.display = 'block';
                
                const scoreDebugInfo = document.getElementById('scoreDebugInfo');
                if (scoreDebugInfo) {
                    let debugHTML = '<strong>Score Log:</strong><br>';
                    debugLog.forEach((log, index) => {
                        debugHTML += `Question ${index+1}: ${log.questionText} - Option: ${log.optionText}<br>`;
                        for (let scoreType in log.scores) {
                            debugHTML += `  - ${scoreType}: ${log.scores[scoreType]}<br>`;
                        }
                    });
                    scoreDebugInfo.innerHTML = debugHTML;
                }
            }
            
            console.log("Score explanation table updated successfully");
        } catch (error) {
            console.error("Error updating score explanation table:", error);
        }
    }
    
    // Show improvement areas
    function showImprovementAreas(finalScores) {
        console.log("Showing improvement areas");
        
        try {
            const improvementList = document.getElementById('improvementList');
            if (!improvementList) {
                console.error("Improvement list element not found");
                return;
            }
            
            improvementList.innerHTML = '';
            
            const scoreTypes = {
                awareness: 'Understanding Online Threats',
                confidence: 'Confidence in Online Situations',
                habits: 'Safe Online Habits',
                support: 'Helping Others Use Internet Safely',
                trust: 'Critical Evaluation of Online Content',
                preparedness: 'Preparation for Cyber Challenges'
            };
            
            // Based on final scores, determine improvement areas (scores below 7)
            let hasImprovementAreas = false;
            for (let scoreType in finalScores) {
                if (finalScores.hasOwnProperty(scoreType) && finalScores[scoreType] < 7) {
                    hasImprovementAreas = true;
                    
                    const listItem = document.createElement('li');
                    const categoryTitle = document.createElement('h4');
                    categoryTitle.style.fontWeight = 'bold';
                    categoryTitle.style.color = '#212529';
                    categoryTitle.textContent = scoreTypes[scoreType];
                    
                    const suggestionDiv = document.createElement('div');
                    suggestionDiv.innerHTML = 'Needs improvement. Suggestions: <ul><li>This is a sample improvement suggestion</li><li>Based on your score, consider strengthening your knowledge in this area</li></ul>';
                    
                    listItem.appendChild(categoryTitle);
                    listItem.appendChild(suggestionDiv);
                    improvementList.appendChild(listItem);
                }
            }
            
            if (!hasImprovementAreas) {
                const listItem = document.createElement('li');
                listItem.innerHTML = '<h4 style="color: #28a745; font-weight: bold;">Great Job!</h4><p>You performed excellently in all security areas. Keep up these good habits and consider:</p><ul><li>Sharing your cybersecurity knowledge with family and friends</li><li>Staying updated on the latest security trends</li><li>Exploring advanced security techniques and methods</li></ul>';
                improvementList.appendChild(listItem);
            }
            
            console.log("Improvement areas displayed successfully");
        } catch (error) {
            console.error("Error showing improvement areas:", error);
        }
    }
    
    // Show missed questions
    function showMissedQuestions() {
        console.log("Showing missed questions");
        
        try {
            const missedQuestionsList = document.getElementById('missedQuestionsList');
            if (!missedQuestionsList) {
                console.error("Missed questions list element not found");
                return;
            }
            
            missedQuestionsList.innerHTML = '';
            
            let hasSuboptimalAnswers = false;
            
            console.log("Checking for suboptimal answers, userAnswers:", userAnswers);
            
            // Loop through all questions in the quiz
            for (let i = 0; i < quizData.questions.length; i++) {
                const question = quizData.questions[i];
                
                // Find the answer for this question number
                const userAnswerData = userAnswers[i];
                
                if (userAnswerData) {
                    const optionIndex = userAnswerData.optionIndex;
                    
                    // Calculate total score of user's selected option
                    let userOptionTotalScore = 0;
                    const userOption = question.options[optionIndex];
                    for (let category in userOption.scores) {
                        if (userOption.scores.hasOwnProperty(category)) {
                            userOptionTotalScore += userOption.scores[category];
                        }
                    }
                    
                    // Find option with the highest score
                    let maxTotalScore = -Infinity;
                    let bestOptionIndex = -1;
                    
                    for (let j = 0; j < question.options.length; j++) {
                        const option = question.options[j];
                        let optionTotalScore = 0;
                        
                        for (let category in option.scores) {
                            if (option.scores.hasOwnProperty(category)) {
                                optionTotalScore += option.scores[category];
                            }
                        }
                        
                        if (optionTotalScore > maxTotalScore) {
                            maxTotalScore = optionTotalScore;
                            bestOptionIndex = j;
                        }
                    }
                    
                    console.log(`Question ${i+1}: User selected option ${optionIndex+1} with score ${userOptionTotalScore}, best option is ${bestOptionIndex+1} with score ${maxTotalScore}`);
                    
                    // If user didn't select the highest scoring option, add to missed questions
                    if (bestOptionIndex !== optionIndex) {
                        hasSuboptimalAnswers = true;
                        
                        const missedQuestionItem = document.createElement('div');
                        missedQuestionItem.className = 'missed-question-item';
                        
                        const questionText = document.createElement('div');
                        questionText.className = 'missed-question-text';
                        questionText.textContent = `Question ${i+1}: ${question.text}`;
                        
                        const userAnswerText = document.createElement('div');
                        userAnswerText.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
                        userAnswerText.innerHTML = '<strong>Your Choice:</strong> ' + question.options[optionIndex].text + ' (Total score: ' + userOptionTotalScore + ')';
                        
                        const betterAnswerText = document.createElement('div');
                        betterAnswerText.className = 'correct-answer';
                        betterAnswerText.setAttribute('style', 'color: #212529 !important; margin-bottom: 5px;');
                        betterAnswerText.innerHTML = '<strong>Better Choice:</strong> ' + question.options[bestOptionIndex].text + ' (Total score: ' + maxTotalScore + ')';
                        
                        const questionDescription = document.createElement('div');
                        questionDescription.className = 'question-description';
                        questionDescription.textContent = question.description || "No description";
                        
                        missedQuestionItem.appendChild(questionText);
                        missedQuestionItem.appendChild(userAnswerText);
                        missedQuestionItem.appendChild(betterAnswerText);
                        missedQuestionItem.appendChild(questionDescription);
                        
                        missedQuestionsList.appendChild(missedQuestionItem);
                    }
                } else {
                    console.warn(`No user answer found for question ${i+1}`);
                }
            }
            
            // If all user selections were optimal
            if (!hasSuboptimalAnswers) {
                const perfectScore = document.createElement('div');
                perfectScore.textContent = 'Congratulations! You selected the highest scoring option for all questions.';
                perfectScore.style.textAlign = 'center';
                perfectScore.style.padding = '20px';
                perfectScore.style.fontWeight = 'bold';
                perfectScore.style.color = '#28a745';
                missedQuestionsList.appendChild(perfectScore);
            }
            
            console.log("Missed questions displayed successfully");
        } catch (error) {
            console.error("Error showing missed questions:", error);
        }
    }
    
    // Create radar chart
    function createRadarChart(finalScores) {
        console.log("Creating radar chart");
        
        try {
            const ctx = document.getElementById('radarChart').getContext('2d');
            
            // Check if chart instance already exists, if so, destroy it
            if (window.quizRadarChart) {
                window.quizRadarChart.destroy();
            }
            
            window.quizRadarChart = new Chart(ctx, {
                type: 'radar',
                data: {
                    labels: ['Awareness', 'Confidence', 'Habits', 'Support', 'Trust', 'Preparedness'],
                    datasets: [
                        {
                            label: 'Your Scores',
                            data: [
                                finalScores.awareness,
                                finalScores.confidence, 
                                finalScores.habits,
                                finalScores.support,
                                finalScores.trust,
                                finalScores.preparedness
                            ],
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: 'rgba(54, 162, 235, 1)',
                            fill: true
                        }
                    ]
                },
                options: {
                    scales: {
                        r: {
                            suggestedMin: 0,
                            suggestedMax: 10,
                            ticks: {
                                beginAtZero: true,
                                max: 10,
                                stepSize: 2
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.raw !== null) {
                                        label += context.raw.toFixed(1);
                                    }
                                    return label;
                                }
                            }
                        }
                    }
                }
            });
            
            console.log("Radar chart created successfully");
        } catch (error) {
            console.error("Error creating radar chart:", error);
        }
    }
}); 